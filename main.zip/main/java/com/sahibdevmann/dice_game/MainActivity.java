package com.sahibdevmann.dice_game;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    static int fDiceRoll = 0;

    public void playerDice(View view){
        Button buttonMain = (Button) findViewById(R.id.button);
        ImageView imgButton = (ImageButton) findViewById(R.id.imageButton2);
        //Toast.makeText(MainActivity.this, "Image Clicked ",Toast.LENGTH_LONG).show();
        buttonMain.setEnabled(true);
        Dice dice = new Dice();
        int diceRoll = dice.rollDice();
        displayDice(diceRoll,2);
        declareWinner(diceRoll);
        imgButton.setEnabled(false);
    }

    public void autoDice(View view){
        //Toast.makeText(MainActivity.this, "Button Clicked ",Toast.LENGTH_LONG).show();
        Button buttonMain = (Button) findViewById(R.id.button);
        TextView mainMsg = (TextView) findViewById(R.id.textView);
        ImageView imgButton = (ImageButton) findViewById(R.id.imageButton2);

        String message;
        Dice dice = new Dice();

        mainMsg.setTextColor(Color.parseColor("#000000"));
        message = "Click Button to Play";
        mainMsg.setText(message);

        int diceRoll = dice.rollDice();
        fDiceRoll = diceRoll;
        //Toast.makeText(MainActivity.this, Integer.toString(diceRoll),Toast.LENGTH_LONG).show();
        displayDice(diceRoll,1);
        buttonMain.setEnabled(false);

        message = "Roll (Click) your Dice Below";
        mainMsg.setText(message);
        imgButton.setEnabled(true);
    }

    private void declareWinner(int player){
        String message;
        TextView mainMsg = (TextView) findViewById(R.id.textView);
        Button buttonMain = (Button) findViewById(R.id.button);

        if (player > fDiceRoll) {
            message = "Your are winner";
            mainMsg.setTextColor(Color.parseColor("#006400"));
        }
        else if (player < fDiceRoll) {
            message = "You lost";
            mainMsg.setTextColor(Color.parseColor("#8B0000"));
        }
        else
            message = "It is a Draw";
        mainMsg.setText(message);

        message = "Play Again";
        buttonMain.setText(message);
    }


    private void displayDice(int num, int dice){
        ImageView obj;
        if (dice == 1)
            obj = (ImageView) findViewById(R.id.imageView);
        else if (dice == 2)
            obj = (ImageButton) findViewById(R.id.imageButton2);
        else
            obj = (ImageButton) findViewById(R.id.imageButton2);

        switch (num){
            case 1:
                setDice1(obj);
                break;
            case 2:
                setDice2(obj);
                break;
            case 3:
                setDice3(obj);
                break;
            case 4:
                setDice4(obj);
                break;
            case 5:
                setDice5(obj);
                break;
            case 6:
                setDice6(obj);
                break;
            default:
                TextView mainMessage = (TextView) findViewById(R.id.textView);
                Toast.makeText(MainActivity.this, "Retry",Toast.LENGTH_LONG).show();
        }
    }

    private void setDice1(ImageView obj){
        obj.animate().rotationBy(3600).setDuration(2000);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice1, getApplicationContext().getTheme()));
        } else {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice1));
        }
    }

    private void setDice2(ImageView obj){
        obj.animate().rotationBy(3600).setDuration(2000);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice2, getApplicationContext().getTheme()));
        } else {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice2));
        }
    }

    private void setDice3(ImageView obj){
        obj.animate().rotationBy(3600).setDuration(2000);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice3, getApplicationContext().getTheme()));
        } else {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice3));
        }
    }

    private void setDice4(ImageView obj){
        obj.animate().rotationBy(3600).setDuration(2000);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice4, getApplicationContext().getTheme()));
        } else {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice4));
        }
    }

    private void setDice5(ImageView obj){
        obj.animate().rotationBy(3600).setDuration(2000);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice5, getApplicationContext().getTheme()));
        } else {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice5));
        }
    }

    private void setDice6(ImageView obj){
        obj.animate().rotationBy(3600).setDuration(2000);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice6, getApplicationContext().getTheme()));
        } else {
            obj.setImageDrawable(getResources().getDrawable(R.drawable.dice6));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imgButton = (ImageButton) findViewById(R.id.imageButton2);
        imgButton.setEnabled(false);
    }
}
