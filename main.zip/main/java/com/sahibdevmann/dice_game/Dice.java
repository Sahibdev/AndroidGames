package com.sahibdevmann.dice_game;

import java.util.Random;

/**
 * Created by Sahibdev on 12/3/2017.
 */

public class Dice {
        public void Dice(){
        }

        public int rollDice(){
            Random rand = new Random();
            int diceRoll = rand.nextInt(6) + 1;
            return diceRoll;
        }
}
