/**
 * Club Class is resposible for handling the Club details and working
 * 
 * @author Amrit
 * @version (a version number or a date)
 */
import java.util.*;
import java.time.LocalTime;
import java.time.LocalDate;

public class Club
{
    private String clubName;
    public LocalTime openTime;
    public LocalTime closeTime;
    private ArrayList<Member> member;
    private ArrayList<Booking> booking;
    private ArrayList<Sport> sport;
    
    public Club(String name) throws Exception
    {
        this.clubName=name;
        this.openTime=LocalTime.of(8,0,0,0);
        this.closeTime=LocalTime.of(23,0,0,0);
        member = new ArrayList<Member>();
        sport = new ArrayList<Sport>();
        booking = new ArrayList<Booking>();
        readMembersFile();
        readBookingFile();
        readSportsFile();
      
    }
    
    /**
     * Method to read data of members from file
     *
     * @throws Exception
     */
    public void readMembersFile() throws Exception
    {
        //IO_Support.println("Fileread meber");
        ArrayList<String> memberFromFile = FileUtility.readFile("members.txt");
        
        for (int i = 0; i < memberFromFile.size(); i++) 
        {
            //IO_Support.println(memberFromFile.get(i));
            member.add(new Member(memberFromFile.get(i)));
        }
    }
    
    /**
     * Method to read data of bookings from file
     *
     * @throws Exception
     */
    public void readBookingFile() throws Exception
    {
        //IO_Support.println("Fileread booking");
        ArrayList<String> bookingFromFile = FileUtility.readFile("booking1.txt");
        for (int i = 0; i < bookingFromFile.size(); i++) 
        {
            //Booking booking = new Booking(bookingFromFile.get(i));
            String bookingDtls = new String(bookingFromFile.get(i));
            //IO_Support.println(bookingDtls);
            booking.add(new Booking(bookingDtls));
        }
    }
    
    /**
     * Method to read data of sports from file
     *
     * @throws Exception when there is corrupt data in file
     */
    public void readSportsFile() throws Exception
    {
        //IO_Support.println("Fileread sport");
        ArrayList<String> sportFromFile = FileUtility.readFile("sports.txt");
        //IO_Support.println("here--");
        
        for (int i = 0; i < sportFromFile.size(); i++) 
        {
            String sportDtls = sportFromFile.get(i);
            StringTokenizer st = new StringTokenizer(sportDtls,","); 
            //System.out.print(sportFromFile.get(i));
            try 
            {
                String st1 = new String(st.nextToken());
                //IO_Support.println(st1);
                    if (st1.equalsIgnoreCase("Tennis")) {
                        sport.add(new Tennis(sportFromFile.get(i)));
                }   else if (st1.equalsIgnoreCase("Squash")) {
                        sport.add(new Squash(sportFromFile.get(i)));
                }   else if (st1.equalsIgnoreCase("Basketball")) {
                        sport.add(new Basketball(sportFromFile.get(i))); }
                    else {
                        IO_Support.println("No such Sport");
                }
            } 
            catch (Exception e) 
            {
               // new MyException("SportFile data Corrupt");
            }
        }

    }
    
    public ArrayList<String> getAllAvailableCourts(String sportName)
    {
        ArrayList<String> courtNumlist = new ArrayList<String>();
        for(Sport sportObj : sport )
        {
            if(sportObj.getSportName().equalsIgnoreCase(sportName))
            {
                courtNumlist = sportObj.getAllCourtNum();
            }
        }
        return courtNumlist; 
    }
    
    public ArrayList<String> getAvailableCourts(LocalDate bookingDt,LocalTime bookingStrTime,LocalTime bookingEndTime,String sportName)
    {
        ArrayList<String> courtNumAvailList = new ArrayList<String>();
        //courtNumAvailList = null;
        boolean checkFlag;
       
        for(String courtNum : getAllAvailableCourts(sportName) )
        {
            checkFlag=true;
            if (booking.isEmpty())
            { 
               courtNumAvailList=getAllAvailableCourts(sportName); 
            }
            else
            {
                for(Booking bookingObj : booking )
                {
                    if(bookingObj.overlapBooking(bookingDt, bookingStrTime, bookingEndTime, courtNum))
                    {
                        checkFlag=false;
                    }
                }
                
                if(checkFlag)
                {
                  courtNumAvailList.add(courtNum);  
                }
            }
        }
        return courtNumAvailList; 
    }
    
    public ArrayList<String> getMemberBookings(String memberId)
    {
        String BookingObjStr,bookingMem;
        ArrayList<String> BookingObjStrlist = new ArrayList<String>();
        for(Booking bookingObj:booking)
        {
               BookingObjStr=bookingObj.getBookingdtls();
               String[] parts=BookingObjStr.split(",");
               bookingMem = parts[3];
               IO_Support.println(bookingMem);
               if(bookingMem.equals(memberId) && bookingObj.checkDate())
               {
                   BookingObjStrlist.add(BookingObjStr);
               }
        }
        return BookingObjStrlist;
    }
    
   public ArrayList<String> getCourtBookings(String sportName,String court)
   {
       String BookingObjStr,bookingCou;
        ArrayList<String> BookingObjStrlist = new ArrayList<String>();
        for(Booking bookingObj:booking)
        {
               BookingObjStr=bookingObj.getBookingdtls();
               String[] parts=BookingObjStr.split(",");
               bookingCou = parts[5];
               IO_Support.println(bookingCou);
               if(bookingCou.equalsIgnoreCase(court) && parts[4].equalsIgnoreCase(sportName) && bookingObj.checkDate())
               {
                   BookingObjStrlist.add(BookingObjStr);
               }
        }
        return BookingObjStrlist;
   }
    
    public boolean setClubBooking(LocalDate bookingDate,LocalTime bookingStrTime,LocalTime bookingTimeEnd,String validateMemberId,String sportName,String court)
    {
        ArrayList<String> bookingDtlsFile = new ArrayList<String>();
        Booking bookObj = new Booking(bookingDate,bookingStrTime,bookingTimeEnd,validateMemberId,sportName,court);
        booking.add(bookObj);
        //Collections.sort(booking);
        
        for(Booking bookObjLoop:booking)
        {
            String bookingDtls= new String(bookObjLoop.getBookingdtls());
            IO_Support.println(bookingDtls);
            bookingDtlsFile.add(bookingDtls);
        }
        
        if(!bookingDtlsFile.isEmpty())
        {
            Collections.sort(bookingDtlsFile);
            try
            {
                IO_Support.println("Writing in file");
                FileUtility.writeFile("booking1.txt",bookingDtlsFile);
            }
            catch(Exception ex)
            {
                booking.remove(bookObj);
                return false;
            }
            return true;
        }
        else
        {
            booking.remove(bookObj);
            return false;
        }
    }
    
    public boolean deleteBooking(String memberId,LocalDate bookingDt,LocalTime bookingTime)
    {
        boolean foundFlag=false;
        ArrayList<String> bookingDtlsFile = new ArrayList<String>();
        for(Booking bookObjLoop:booking)
        {
            foundFlag=bookObjLoop.findBooking(memberId,bookingDt,bookingTime);
            if(foundFlag) 
            {
                bookObjLoop.delete();
            }
            String bookingDtls= new String(bookObjLoop.getBookingdtls());
            IO_Support.println(bookingDtls);
            bookingDtlsFile.add(bookingDtls);         
        }
        
        if(foundFlag)
        {
            Collections.sort(bookingDtlsFile);
            try
            {
                IO_Support.println("Writing in file");
                FileUtility.writeFile("booking1.txt",bookingDtlsFile);
                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }    
        
        return false;
    }
        
    public boolean validateSportName(String sportName, String memberId)
    {
        for(Sport sportObj : sport )
        {
            if(sportObj.getSportName().equalsIgnoreCase(sportName) && memberId.equals(null))
            {
                return true;
            }
            else if(sportObj.getSportName().equalsIgnoreCase(sportName) && !memberId.equals(null))
            {
                for(Member memObj : member )
                {
                    if(memObj.validate(memberId,sportName));
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean validateMemberName(String memberId)
    {
        for(Member memObj : member )
        {
            if(memObj.getMemberId().equalsIgnoreCase(memberId))
            {
                return true;
            }
        }
        return false;
    }
    
    public boolean validateDuration(int bookingDuration,String sportName)
    {
        for(Sport sportObj : sport )
        {
            if(sportObj.getSportName().equalsIgnoreCase(sportName))
            {
                if(sportObj.getMaxTime() <=  bookingDuration)
                        return true;
                else
                        return false;
            }    
        }
        return false;
    }
    
    public boolean validateCourtNum(String sportName,String court)
    {
        ArrayList<String> courtNumAvailList = new ArrayList<String>();
        for(String courtNum : getAllAvailableCourts(sportName) )
        {
            if(courtNum.equalsIgnoreCase(court))
            {
                return true;
            }
        }
        return false;
    }
    
    public String toString()
    {
        return "Not implmented yet";
    }

}