/**
 * Write a description of class Member here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;
import java.util.StringTokenizer;  

public class Member
{
   private String memberId;
   private String memberName;
   private boolean isFinancial;
   private ArrayList<String> sport;
   
   public Member(String memberDtls) throws Exception
   {
       try
       {
           StringTokenizer st = new StringTokenizer(memberDtls,","); 
           this.memberId = st.nextToken();
           this.memberName = st.nextToken();
           this.isFinancial = Boolean.valueOf(st.nextToken());
       
           if(isFinancial)
           {
               while (st.hasMoreTokens()) 
               {  
                   sport.add(st.nextToken());   
               }
           }
       }
       catch(Exception e)
       {
           new ExceptionMsg("Please check data in Member File");
       }
   }
    
    public void setMemberId(String memberId)
    {
        this.memberId=memberId;
    }
    
    public String getMemberId()
    {
        return memberId;
    }
    
    public void addBooking()
    {
      
    }
    
   public boolean isFinancial()
   {
       if(isFinancial=true)
       {
            return true;
       }
       else return false;
   }

   public String toString()
   {
        return "The member name is:"+memberName+"\t"+"The member Id is:"+memberId;
   }
   
   public boolean validate(String memId, String sportName)
   {
       if(this.memberId.equals(memId) && this.isFinancial())
       {
           for(String sportObj : sport)
           {
               if(sportObj.equalsIgnoreCase(sportName))
               {
                   return true;
               }
           }
       }
       return false;
   }
}