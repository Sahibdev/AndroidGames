
/**
 * Write a description of class UI here.
 * 
 * @author Amrit
 * @version (a version number or a date)
 */
import java.util.*;
import java.time.LocalDate;
import java.time.LocalTime;
public class UserInterface
{
    private Club myClub;
    private String sportName,memberId,bookingDt,bookingTime,court;
    private int bookingDuration;
    private boolean validateSport, validateMemberId, validateCourtNum, bookingStatus;
    private LocalDate bookingDate = null;
    private LocalTime bookingStrTime = null;
    private LocalTime bookingTimeEnd = null;
    private ArrayList<String> list = new ArrayList<String>();
    
    
    public UserInterface(Club myClub)
    {
        this.myClub = myClub; 
    }
  
    public void run()
    {
        boolean condition=true;
        while(condition)
            switch (menu() ) 
            {
                    case 1:
                        showAvailableCourts();
                        break;
                    case 2:
                        makeBooking();
                        break;
                    case 3:
                        showMemberBookings();
                        break;
                     case 4:
                        showCourtBookings();
                      case 5:
                        deleteBooking();
                        break;      
                     case 6:
                        IO_Support.println("Quiting...");
                        condition = false;
                        return;   
                     default:
                        System.out.println ( "Invalid option" );
                        break;
            }
    }
    
    private int menu()
    {   
           IO_Support.println ("|-------------------------------------------------|");
            IO_Support.println ("| 1 - Show Available Courts                      |");
            IO_Support.println ("| 2 - Make Booking for Member                    |");
            IO_Support.println ("| 3 - Show Member Bookings                       |");
            IO_Support.println ("| 4 - Show Court Bookings                        |");
            IO_Support.println ("| 5 - Delete Booking                             |");
            IO_Support.println ("| 6 - Exit                                        |" );
            IO_Support.println("|-------------------------------------------------|");
            return IO_Support.getInteger("Select Option: ");
     }
     
    private void showAvailableCourts()
    {
      /*sportName = IO_Support.getString("Please Enter sport name : Tennis , Squash or Basketball");
       validateSport = myClub.validateSportName(sportName);
       if (validateSport)
       {
           list = myClub.getAllAvailableCourts(sportName);
           IO_Support.println(list);
       }*/
       memberId = null;
       getBookingdtls(memberId);     
    } 
     
    private void makeBooking()
    {
        memberId=IO_Support.getString("Please Enter Member Id");
        validateMemberId = myClub.validateMemberName(memberId);
        if (validateMemberId)
        {
            getBookingdtls(memberId);
            if (!list.isEmpty())
            {
                court = IO_Support.getString("Please Enter Court Number");
                validateCourtNum = myClub.validateCourtNum(sportName,court);
                if(validateCourtNum)
                {
                    for (String courtValidate : list)
                    {
                        IO_Support.println(courtValidate);
                        if(courtValidate.equals(court))
                        {
                            IO_Support.println(sportName);
                            if(myClub.setClubBooking(bookingDate,bookingStrTime,bookingTimeEnd,memberId,sportName,court))IO_Support.println("Booking Saved Successfully");
                            else IO_Support.println("Booking Saved Successfully");
                        }
                    }
                }
                else IO_Support.getString("Not a Validate courtNumber");
            }
            else IO_Support.getString("Court List Empty");
        }    
        else
        IO_Support.println("Not a Validate MemberID");
    }
    
    public void showMemberBookings()
    {
        list = new ArrayList<String>();
        memberId=IO_Support.getString("Please Enter Member Id");
        validateMemberId = myClub.validateMemberName(memberId);
        if (validateMemberId)
        {
            list = myClub.getMemberBookings(memberId);
            IO_Support.println(list);
        }
        else IO_Support.println("Not a Validate MemberID");
    }
    
      private void showCourtBookings()
      {
          memberId = null;
          sportName = IO_Support.getString("Please Enter sport name : Tennis , Squash or Basketball");
          validateSport = myClub.validateSportName(sportName,memberId);
          if (validateSport)
          {
            court = IO_Support.getString("Please Enter Court Number");
            validateCourtNum = myClub.validateCourtNum(sportName,court);
            if(validateCourtNum)
            {
                list = myClub.getCourtBookings(sportName,court);
                IO_Support.println(list);
            }
            else IO_Support.getString("Not a Validate courtNumber");
          }
          else IO_Support.getString("Not a Validate MemberID");
      }
      
      private void deleteBooking()
      {
          memberId=IO_Support.getString("Please Enter Member Id");
          validateMemberId = myClub.validateMemberName(memberId);
          if (validateMemberId)
          {
              bookingDt=IO_Support.getString("Please Enter booking Date in ('YYYY-MM-DD')");
               bookingDate = DateUtility.convertDate(bookingDt);
               if (bookingDate == null)
               {
                   IO_Support.println("You Entered Wrong date ");
               }                  
               else
               {
                   if (bookingDate.isAfter(LocalDate.now().plusDays(7)))
                       IO_Support.println("Cannot add booking before seven days");
                   else if (bookingDate.isBefore(LocalDate.now()))
                       IO_Support.println("Cannot add booking in previous dates");
                   else
                      {
                        bookingTime=IO_Support.getString("Please Enter booking Start Time in ('hh:mm')");
                        bookingStrTime = DateUtility.convertTime(bookingTime);
                        if(bookingStrTime == null)
                        {
                            IO_Support.println("You Entered Invalid Time");
                        }
                        else if(bookingStrTime.isBefore(myClub.openTime))
                        {
                            IO_Support.println("Club is not open during this time");
                        }
                        else
                        {
                            bookingStatus=myClub.deleteBooking(memberId,bookingDate,bookingStrTime);
                        }
                   
                    }
                }
          }
          else IO_Support.getString("Not a Validate MemberID");
      }
      
      private void getBookingdtls(String member)
      {
          sportName = IO_Support.getString("Please Enter sport name : Tennis , Squash or Basketball");
          validateSport = myClub.validateSportName(sportName,member);
          if (validateSport)
          {
               bookingDt=IO_Support.getString("Please Enter booking Date in ('YYYY-MM-DD')");
               bookingDate = DateUtility.convertDate(bookingDt);
               if (bookingDate == null)
               {
                   IO_Support.println("You Entered Wrong date ");
               }                  
               else
               {
                   if (bookingDate.isAfter(LocalDate.now().plusDays(7)))
                       IO_Support.println("Cannot add booking before seven days");
                   else if (bookingDate.isBefore(LocalDate.now()))
                       IO_Support.println("Cannot add booking in previous dates");
                   else
                      {
                        bookingTime=IO_Support.getString("Please Enter booking Start Time in ('hh:mm')");
                        bookingStrTime = DateUtility.convertTime(bookingTime);
                        if(bookingStrTime == null)
                        {
                            IO_Support.println("You Entered Invalid Time");
                        }
                        else if(bookingStrTime.isBefore(myClub.openTime))
                        {
                            IO_Support.println("Club is not open during this time");
                        }
                        else
                        {
                            bookingDuration=IO_Support.getInteger("Please Enter booking time in mins)");
                            if (myClub.validateDuration(bookingDuration,sportName)) 
                                IO_Support.println("Please enter a valid Time in Minutes");
                            else
                            {
                                bookingTimeEnd = bookingStrTime.plusMinutes(Long.valueOf(bookingDuration));
                                if(bookingTimeEnd.isAfter(myClub.closeTime))
                                   IO_Support.println("Club is closes before this time");
                                else
                                {
                                    list=myClub.getAvailableCourts(bookingDate,bookingStrTime,bookingTimeEnd,sportName);
                                    if (list.isEmpty())
                                    {
                                        IO_Support.println("No court is available");  
                                    }
                                    else
                                    {
                                        IO_Support.println("Following Courts are Available");
                                        IO_Support.println(list);
                                    }
                                }   
                            }
                        }
                   }                   
               }
          }
          else
                IO_Support.println("Not a Validate Sport Name");
      }    
       
} // end class