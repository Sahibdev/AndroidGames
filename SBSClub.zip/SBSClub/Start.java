/**
 * Loading and Starting Class
 * 
 * @Amrit
 * @version (a version number or a date)
 */
public class Start
{
  public static void main(String[] args)
    {
        try
        {
            Club swinClub = new Club("Swinburne Country Club");
             UserInterface consoleApp = new UserInterface(swinClub);
              consoleApp.run();
        }
        catch (Exception ex)
        {
             System.out.println("Exception thrown  :" + ex);
        }
    } 
}
