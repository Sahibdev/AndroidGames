/**
 * Provides date utility methods for handle LocalDate and LocalTime datatype. It uses Java 8
 * 
 *
 * @author Amrit
 * @version (a version number or a date)
 */
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class DateUtility {

    /**
     * Method to convert String into LocalDate
     *
     * @param String Date in String format
     * @return LocalDate
     */
    public static LocalDate convertDate(String date) 
    {
        LocalDate localDate = null;
        try 
            {
            localDate = LocalDate.parse(date);
            } 
            catch (Exception e) 
            {
            IO_Support.println("Exception in String to Date conversion");
            }
        return localDate;
    }

    /**
     * Method to convert String into LocalTime
     *
     * @param String Time in String format
     * @return LocalTime
     */
    public static LocalTime convertTime(String time) 
    {
        LocalTime localTime = null;
        try 
            {
            localTime = LocalTime.parse(time);
            } 
        catch (Exception e) 
            {
            IO_Support.println("Exception in String to Time conversion");
            }
        return localTime;
    }

    /**
     * Method receives times a LocalTime object, converting to string
     *
     * @param LocalTime Time in LocalTime format
     * @return String
     */
    public static String timeToString(LocalTime time) 
    {
        LocalTime timeString = time;
        return timeString.toString();
    }

    /**
     * Method receives date a LocalDate object, converting to string
     *
     * @param LocalDate Date in LocalDate format
     * @return String
     */
    public static String dateToString(LocalDate date) 
    {
        LocalDate dateString = date;
        return dateString.toString();
    }
}