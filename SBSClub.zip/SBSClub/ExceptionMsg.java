
/**
 * Write a description of class ExceptionMsg here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ExceptionMsg extends Exception
{
    public ExceptionMsg(String message) 
    {
        super(message);
    }
}
