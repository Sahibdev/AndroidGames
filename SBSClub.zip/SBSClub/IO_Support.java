/**
 * Class IO_Support is used for User Interface Messages
 *
 * @author Amrit
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.*;
import java.time.*;

public class IO_Support 
{
    private static Scanner in = new Scanner(System.in);
   
    /**
     * Method is used to get String Value
     *
     * @param String message to be print
     * @return String
     */
    public static String getString(String message) 
    {
        System.out.print(message + " ");
        return in.nextLine();
    }

    /**
     * Method is used to get Double Value
     *
     * @param String message to be print
     * @return Double
     */
    public static Double getDouble(String message) 
    {
        Double d = 0.00;
        while (true) {
            try {
                System.out.print(message + " ");
                d = Double.parseDouble(in.nextLine());
                break;
            } catch (Exception e) {
                System.out.println("Not a valid Double");
            }
        }
        return d;
    }

    /**
     * Method is used to get Integer Value
     *
     * @param String message to be print
     * @return Integer
     */
    public static Integer getInteger(String message) 
    {
        Integer i = 0;
        while (true) {
            try {
                System.out.print(message + " ");
                i = Integer.parseInt(in.nextLine());
                break;
            } catch (Exception e) {
                System.out.println("Not a valid Integer");
            }
        }
        return i;
    }

    /**
     * Method is used to Print message
     *
     * @param String message to be print
     */
    public static void println(String message) 
    {
        System.out.println(message);
    }
    
    /**
     * Method is used to Print message
     *
     * @param String message to be print
     */
    public static void println(ArrayList<String> List) 
    {
        if(List.isEmpty())
        {
            System.out.println("NoThing");
        }
        else
        {
            for(String s: List)
            {
                System.out.println(s);
            }
        }
    }
}