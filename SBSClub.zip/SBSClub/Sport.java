
/**
 * Write a description of class Sport here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.StringTokenizer; 
import java.util.*;

public abstract class Sport
{
    // instance variables - replace the example below with your own
    private String sportName;
    private double usageFee;
    private double affiliationFee;
    private double insuranceFee;
    private ArrayList<Court> court;
    public int maxtime;

    /**
     * Constructor for objects of class Sport
     */
    public Sport(String spotdtls)
    {
       
       try
       {   
           court = new ArrayList<Court>(); 
           StringTokenizer st = new StringTokenizer(spotdtls,","); 
           this.sportName = st.nextToken();
           this.usageFee = Double.parseDouble(st.nextToken());
           this.insuranceFee = Double.parseDouble(st.nextToken());
           this.affiliationFee = Double.parseDouble(st.nextToken());
           //IO_Support.println("sportName -->" + sportName + "usageFee-->" + usageFee + "insuranceFee-->" + insuranceFee + "affiliationFee-->" + affiliationFee);
           while (st.hasMoreTokens()) 
           {  
               //IO_Support.println(st.nextToken());
               String courtid = new String(st.nextToken());
               court.add(new Court(courtid));
               //IO_Support.println(courtid);
           }
       }
       catch(Exception e)
       {
           new ExceptionMsg("Please Check sports File");
       }
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
   public String getSportName()
   {
       return sportName;
   }
   
   public ArrayList<String> getAllCourtNum()
   {
       ArrayList<String> courtNum = new ArrayList<String>();
       String courtStrNum;
       for(Court courtObj : court)
       {
          courtStrNum = new String(courtObj.getcourtNum());
          courtNum.add(courtStrNum);
       }
       return courtNum;
   }
   
   int getMaxTime()
   {
       return maxtime;
   }
}
