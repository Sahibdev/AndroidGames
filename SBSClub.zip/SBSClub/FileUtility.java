/**
 * FileUtility Class is used for Reading and Writing Files
 *
 * @author Amrit
 * @version (a version number or a date)
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class FileUtility {

    /**
     * Method to read from a file and return String ArrayList
     *
     * @param String Name of the File to be read
     * @return ArrayList<String>
     */ 
    public static ArrayList<String> readFile(String fileName) throws Exception 
    {
        ArrayList<String> data = new ArrayList<>();
        BufferedReader reader = null;
        
        try {
                reader = new BufferedReader(new FileReader(fileName));
                String line = reader.readLine();
                while(line != null) 
                {
                    data.add(line);
                    line = reader.readLine();
                }
                reader.close();
            }
            catch(FileNotFoundException e) 
            {
                    IO_Support.println(fileName +"not found " + e.getMessage());
            }
            catch(IOException e) 
            {
                IO_Support.println("Cannot Read File " + e.getMessage());
            }
        return data;
    }

    /**
     * Method to write to file from String ArrayList
     *
     * @param String Name of the File in which StringArrayList is to be written
     * @param ArrayList<String> StringArrayList to be written into file
     * @return ArrayList<String>
     */ 
    public static void writeFile(String fileName, ArrayList<String> data) throws Exception 
    {
        try {
                FileWriter writer = new FileWriter(fileName);
                for(String line:data) 
                {
                    writer.write(line+"\n");
                }
                writer.close();
            }
            catch(IOException e) 
            {
                IO_Support.println("Cannot Read File " + e.getMessage());
            }
    }
}