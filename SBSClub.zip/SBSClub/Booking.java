
/**
 * Write a description of class Booking here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.time.*;
import java.util.*;

public class Booking
{
    private LocalDate bookingDate;
    private LocalTime bookingTimeStart;
    private LocalTime bookingTimeEnd;
    private String bookingMember;
    private String bookedSport;
    private String bookedCourt;
    private boolean bookingStatus;

    /**
     * Constructor for objects of class Booking
     */
    public Booking(String bookingDtls)
    {
       String bookingDtStr, bookingTimeStr, bookingTimeEndStr;
       try
       {  
           StringTokenizer st = new StringTokenizer(bookingDtls,","); 
           bookingDtStr = st.nextToken();
           this.bookingDate = DateUtility.convertDate(bookingDtStr);
           bookingTimeStr = st.nextToken();
           this.bookingTimeStart = DateUtility.convertTime(bookingTimeStr);
           bookingTimeEndStr = st.nextToken();
           this.bookingTimeEnd = DateUtility.convertTime(bookingTimeEndStr);
           this.bookingMember = st.nextToken();
           this.bookedSport = st.nextToken();
           this.bookedCourt = st.nextToken();
           this.bookingStatus = Boolean.valueOf(st.nextToken());
       }
       catch(Exception e)
       {
           new ExceptionMsg("Please Check booking File");
       }
    }
    
    /**
     * Constructor for objects of class Booking
     */
    public Booking(LocalDate bookingDate, LocalTime bookingTime, LocalTime bookingEndTime, String bookedBy, String sport, String courtBooked)
    {
        this.bookingDate = bookingDate;
        this.bookingTimeStart = bookingTime;
        this.bookingTimeEnd = bookingEndTime;
        this.bookingMember = bookedBy;
        this.bookedSport = sport;
        this.bookedCourt = courtBooked;
        bookingStatus = true;
    }
    
    public String getBookingdtls()
    {
        String bookingdtls = new String(this.bookingDate+","+this.bookingTimeStart+","+this.bookingTimeEnd+","+this.bookingMember+","+this.bookedSport+","+this.bookedCourt+","+this.bookingStatus);
        return bookingdtls;
    }

    public boolean overlapBooking(LocalDate bookingDate, LocalTime bookingTimeStart,LocalTime bookingTimeEnd,String courtNum)
    {
        if (bookingDate.isEqual(this.bookingDate) && courtNum.equalsIgnoreCase(this.bookedCourt) && bookingStatus) 
        {
                if (bookingTimeStart.equals(this.bookingTimeStart)) 
                {
                   return true;
                }
                else if (bookingTimeStart.isBefore(this.bookingTimeStart) && bookingTimeEnd.isAfter(this.bookingTimeStart)) 
                {  
                        return true;
                } 
                else if (bookingTimeStart.isAfter(this.bookingTimeStart) && bookingTimeStart.isBefore(this.bookingTimeEnd)) 
                {
                    return true;
                }
        }
        return false;
    }
    
    public boolean findBooking(String bookedBy, LocalDate bookingDate, LocalTime bookingTimeStart)
    {
        if(this.bookingMember.equals(bookedBy) && this.bookingDate.equals(bookingDate) && this.bookingTimeStart.equals(bookingTimeStart))
        {
            return true;
        }
        return false;
    }
    
    public void delete()
    {
        bookingStatus = false;
    }
    
    public boolean checkDate()
    {
        if(this.bookingDate.isAfter(LocalDate.now()))
        {
            return true;
        }
        else return false;
    }
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return y;
    }
}
